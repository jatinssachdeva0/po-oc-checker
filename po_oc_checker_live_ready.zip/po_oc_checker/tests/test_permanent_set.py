from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from parsers import parse_purchase_order, parse_order_confirmation
from comparator import compare_documents, overall_status

F = ROOT / "tests" / "fixtures"

PAIRS = [
    ("4500037402.pdf", "Order Confirmation 46156426 from 10.03.2026.PDF", 5, "APPROVED - ITEM PRICES MATCH"),
    ("4500037664.pdf", "Order Confirmation 46183940 from 22.04.2026.PDF", 1, "REVIEW REQUIRED"),
    ("4500038497.pdf", "Order Confirmation 46212466 from 09.06.2026.pdf", 15, "REVIEW REQUIRED"),
    ("4500038598.pdf", "Order Confirmation 46212469 from 09.06.2026.PDF", 2, "APPROVED - ITEM PRICES MATCH"),
    ("4500039165.pdf", "Order Confirmation 46245219 from 29.07.2026.PDF", 26, "APPROVED - ITEM PRICES MATCH"),
    ("4500039372.pdf", "Order Confirmation 46254907 from 14.08.2026.PDF", 1, "APPROVED - ITEM PRICES MATCH"),
    ("4500039469.pdf", "Order Confirmation 46258345 from 21.08.2026.PDF", 7, "APPROVED - ITEM PRICES MATCH"),
    ("4500033073.pdf", "Order Confirmation 46262310 from 27.08.2026.PDF", 1, "HOLD - MANUAL REVIEW"),
]


def test_all_16_files_present():
    assert len(list(F.glob("*.pdf"))) + len(list(F.glob("*.PDF"))) == 16


def test_permanent_pairs():
    for po_name, oc_name, expected_po_items, expected_status in PAIRS:
        po = parse_purchase_order(F / po_name)
        oc = parse_order_confirmation(F / oc_name)
        assert po.document_no == oc.reference_po
        assert len(po.items) == expected_po_items, (po_name, len(po.items))
        df = compare_documents(po, oc)
        assert overall_status(df, po, oc) == expected_status, (po_name, df[["PO Item", "OC Item", "Status"]].to_dict("records"))


def test_known_price_increase_4500037664():
    po = parse_purchase_order(F / "4500037664.pdf")
    oc = parse_order_confirmation(F / "Order Confirmation 46183940 from 22.04.2026.PDF")
    df = compare_documents(po, oc)
    row = df.iloc[0]
    assert row["PO Item"] == "27040BL1"
    assert row["OC Item"] == "27040BL1"
    assert round(row["Price Difference"], 2) == 26.72
    assert row["Status"] == "PRICE HIGHER"


def test_known_replacement_4500038497():
    po = parse_purchase_order(F / "4500038497.pdf")
    oc = parse_order_confirmation(F / "Order Confirmation 46212466 from 09.06.2026.pdf")
    df = compare_documents(po, oc)
    row = df[df["PO Item"] == "27294N"].iloc[0]
    assert row["OC Item"] == "27040LB"
    assert row["Match Type"] == "REPLACEMENT"
    assert row["Status"] == "ITEM REPLACED"
    assert round(row["OC Unit Price"], 2) == 123.80


def test_po_arithmetic_hold_4500033073():
    po = parse_purchase_order(F / "4500033073.pdf")
    oc = parse_order_confirmation(F / "Order Confirmation 46262310 from 27.08.2026.PDF")
    df = compare_documents(po, oc)
    row = df.iloc[0]
    assert row["Status"] == "MANUAL REVIEW - PO ARITHMETIC"
    assert round(row["Price Difference"], 2) == 26.72
